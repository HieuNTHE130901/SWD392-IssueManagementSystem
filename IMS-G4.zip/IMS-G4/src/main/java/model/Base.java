
package model;

/**
 *
 * @author trung
 */
public class Base {
    
}
